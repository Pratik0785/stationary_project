﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class Product : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["addproduct"] = false;
    }

    //display the product according to category
    protected void write_Click(object sender, EventArgs e)
    {
        Response.Redirect("Product.aspx?cat2=Writing Materials");
        if (Request.QueryString["cat2"] != null)
        {
            DataList1.DataSourceID = null;
            DataList1.DataSource = SqlDataSource1;
            DataList1.DataBind();
        }
    }
    protected void drawing_Click(object sender, EventArgs e)
    {
        Response.Redirect("Product.aspx?cat2=Drawing Materials");
        if (Request.QueryString["cat2"] != null)
        {
            DataList1.DataSourceID = null;
            DataList1.DataSource = SqlDataSource2;
            DataList1.DataBind();
        }
    }
    protected void files_Click(object sender, EventArgs e)
    {
        Response.Redirect("Product.aspx?cat3=Files");
        if (Request.QueryString["cat3"] != null)
        {
            DataList1.DataSourceID = null;
            DataList1.DataSource = SqlDataSource3;
            DataList1.DataBind();
        }
    }
    protected void notebooks_Click(object sender, EventArgs e)
    {
        Response.Redirect("Product.aspx?cat4=Notebooks");
        if (Request.QueryString["cat4"] != null)
        {
            DataList1.DataSourceID = null;
            DataList1.DataSource = SqlDataSource4;
            DataList1.DataBind();
        }
    }

    //passing selected products id and quantity to the cart page and product is added to cart
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Session["addproduct"] = "true";
        if (e.CommandName == "addtocart")
        {
            DropDownList dlist=(DropDownList)(e.Item.FindControl("DropDownList1"));
            Response.Redirect("ViewCart.aspx?Id=" + e.CommandArgument.ToString() + "&quantity=" + dlist.SelectedItem.ToString());
        }
    }

    protected void DataList2_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Session["addproduct"] = "true";
        if (e.CommandName == "addtocart")
        {
            DropDownList dlist = (DropDownList)(e.Item.FindControl("DropDownList1"));
            Response.Redirect("ViewCart.aspx?Id=" + e.CommandArgument.ToString() + "&quantity=" + dlist.SelectedItem.ToString());
        }
    }
    protected void DataList3_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Session["addproduct"] = "true";
        if (e.CommandName == "addtocart")
        {
            DropDownList dlist = (DropDownList)(e.Item.FindControl("DropDownList1"));           
            Response.Redirect("ViewCart.aspx?Id=" + e.CommandArgument.ToString() + "&quantity=" + dlist.SelectedItem.ToString());
        }
    }
    protected void DataList4_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Session["addproduct"] = "true";
        if (e.CommandName == "addtocart")
        {
            DropDownList dlist = (DropDownList)(e.Item.FindControl("DropDownList1"));        
            Response.Redirect("ViewCart.aspx?Id=" + e.CommandArgument.ToString() + "&quantity=" + dlist.SelectedItem.ToString());
        }
    }

    //visiting to cart page after clicking on view cart linkbutton
    protected void cartview_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewCart.aspx");
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;


public partial class Feedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        con.Open();

        //insert data into table
        string insert_query = "insert into feedback values(@name,@username,@message)";
        SqlCommand cmd1 = new SqlCommand(insert_query, con);
        cmd1.Parameters.AddWithValue("@name", TextBox1.Text);
        cmd1.Parameters.AddWithValue("@username", TextBox2.Text);
        cmd1.Parameters.AddWithValue("@message", TextBox3.Text);
        cmd1.ExecuteNonQuery();
        Response.Write("<script>alert('Feedback Send successfully!');</script>");
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
    }
}
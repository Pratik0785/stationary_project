﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class AddProduct : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
        }     
    }
    
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
        GridView1.EditRowStyle.BackColor = System.Drawing.Color.Yellow;
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        String query = "Update products set name=@name,price=@price,category=@category where Id=@id";
        SqlCommand cmd = new SqlCommand(query, con);
        cmd.Parameters.AddWithValue("@name", (GridView1.Rows[e.RowIndex].FindControl("TextBox2") as TextBox).Text.Trim());
        cmd.Parameters.AddWithValue("@price", (GridView1.Rows[e.RowIndex].FindControl("TextBox4") as TextBox).Text.Trim());
        cmd.Parameters.AddWithValue("@category", (GridView1.Rows[e.RowIndex].FindControl("DropDownList1") as DropDownList).SelectedItem.ToString());
        cmd.Parameters.AddWithValue("@id", (GridView1.Rows[e.RowIndex].FindControl("Label2") as Label).Text.Trim());
        cmd.ExecuteNonQuery();
        GridView1.EditIndex = -1;
        SqlDataSource1.DataBind();
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        String query = "Delete * from products where Id=@id";
        SqlCommand cmd = new SqlCommand(query, con);
        cmd.Parameters.AddWithValue("@id", (GridView1.Rows[e.RowIndex].FindControl("Label2") as Label).Text.Trim());
        cmd.ExecuteNonQuery();
        GridView1.EditIndex = -1;
        SqlDataSource1.DataBind();
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddProduct.aspx");
    }
}
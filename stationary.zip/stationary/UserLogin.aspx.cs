﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class UserLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        String query = "select * from register where username='" + TextBox1.Text + "'and password='" + TextBox2.Text + "'";
        SqlCommand cmd = new SqlCommand(query,con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        //if username and password are correct redirect to website
        if(dt.Rows.Count > 0)
        {
            Session["username"] = TextBox1.Text;
            Response.Redirect("UserHome.aspx");
        }

        //if username incoorect display error message
        else
        {
            Label1.Text = "Please Check your Username and Password";
            Label1.ForeColor = System.Drawing.Color.Red;
        }
    }
}
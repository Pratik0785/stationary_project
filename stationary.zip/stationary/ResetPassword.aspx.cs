﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class ResetPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);

        //retrive username from table which is similar to the username entered in the textbox
        SqlCommand cmd = new SqlCommand("select * from register where username=@username", con);
        cmd.Parameters.AddWithValue("@username", TextBox1.Text);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        con.Open();
        int i = cmd.ExecuteNonQuery();

        //if username is present in the table
        //update the password and conform password field
        if (dt.Rows.Count > 0)
        {
            SqlCommand cmd1 = new SqlCommand("update register set password and cpassword'" + TextBox2.Text + "' where username='" + TextBox1.Text + "'", con);
            cmd1.ExecuteNonQuery();
            con.Close();
            Label1.Text = "Password Changed Successfully";
            Response.Redirect("UserLogin.aspx");
        }

        //if username is not found display error message
        else
        {
            Label1.Text = "Please Check your username";
            Label1.ForeColor = System.Drawing.Color.Red;
        }
    }
}
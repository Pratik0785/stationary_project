﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.Web.ApplicationServices;
using System.Web.Security;


public partial class Payment : System.Web.UI.Page
{

    public static string to, from, pass, messageBody;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        mailSend();
        orderAdd();
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox5.Text = "";
        TextBox7.Text = "";

    }

    //after successful payment user gets successful transaction email
    public void mailSend()
    {
        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        string query = "select email from register where username='" + Session["username"] + "'";
        SqlDataAdapter sda = new SqlDataAdapter(query,con);
        DataSet ds = new DataSet();
        sda.Fill(ds);
        MailMessage msg = new MailMessage();
        to = ds.Tables[0].Rows[0]["email"].ToString();
        from = "xeroxcenter037@gmail.com";
        pass = "autoxerox";
        messageBody = "Your transaction for Order Id: '" + Session["orderid"] + " is completed Successfully'";
        msg.To.Add(to);
        msg.From = new MailAddress(from);
        msg.Body = messageBody;
        msg.Subject = "Transaction Updates";
        SmtpClient smtp = new SmtpClient("smtp.gmail.com");
        smtp.EnableSsl = true;
        smtp.Port = 587;
        smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
        smtp.UseDefaultCredentials = false;
        smtp.Credentials = new NetworkCredential(from, pass);
        try
        {
            smtp.Send(msg);
            Response.Write("<script>alert('Transaction Completed Successfully');</script>");
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }

    //the users order is added to the database
    public void orderAdd()
    {
        DataTable dt;
        dt = Session["buyitems"] as DataTable;
        for (int i = 0; i <= dt.Rows.Count - 1; i++)
        {
            string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string ins_query = "insert into orders(orderId,sno,userName,productId,productName,price,quantity,orderDate) values('" + Session["orderid"] + "'," + dt.Rows[i]["sno"] + ",'" + Session["username"] + "'," + dt.Rows[i]["pid"] + ",'" + dt.Rows[i]["pname"] + "'," + dt.Rows[i]["cost"] + "," + dt.Rows[i]["qun"] + ",'" + Session["orderdate"] + "')";
            SqlCommand cmd = new SqlCommand(ins_query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }   
}
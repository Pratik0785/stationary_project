﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
public partial class ViewCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {

            //if cart does not contain any item the payment button is not enabled.
            if(Session["buyitems"]==null)
            {
                paymentbut.Enabled = false;
            }

            //if cart contain an item the payment button is enabled.
            else
            {
                paymentbut.Enabled = true;
            }

            //Adding product to gridview
            Session["addproduct"] = false;
            DataTable dt = new DataTable();
            DataRow dr;
            dt.Columns.Add("sno");
            dt.Columns.Add("pid");
            dt.Columns.Add("pname");
            dt.Columns.Add("proimg");
            dt.Columns.Add("cost");
            dt.Columns.Add("qun");
            dt.Columns.Add("total");

            if (Request.QueryString["Id"] != null)
            {
                //if cart is empty product is added to cart from first row
                if(Session["buyitems"]==null)
                {
                    dr = dt.NewRow();
                    string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
                    SqlConnection con = new SqlConnection(constr);
                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter("select * from products where Id=" + Request.QueryString["Id"], con);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    dr["sno"] = 1;
                    dr["pid"] = ds.Tables[0].Rows[0]["Id"].ToString();
                    dr["pname"] = ds.Tables[0].Rows[0]["name"].ToString();
                    dr["proimg"] = ds.Tables[0].Rows[0]["image"].ToString();
                    dr["cost"] = ds.Tables[0].Rows[0]["price"].ToString();
                    dr["qun"] = Request.QueryString["quantity"];

                    int price = Convert.ToInt32(ds.Tables[0].Rows[0]["price"].ToString());
                    int quantity = Convert.ToInt16(Request.QueryString["quantity"].ToString());
                    int totalPrice = price * quantity;
                    dr["total"] = totalPrice;
                    dt.Rows.Add(dr);

                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    Session["buyitems"] = dt;
                    paymentbut.Enabled = true;

                    GridView1.FooterRow.Cells[5].Text = "Total Amount";
                    GridView1.FooterRow.Cells[6].Text = grandtotal().ToString();
                    Response.Redirect("ViewCart.aspx");
                }

                //if cart already contain product the new product is added fro next row
                else
                {
                    dt = Session["buyitems"] as DataTable;
                    int sr = dt.Rows.Count;

                    dr = dt.NewRow();
                    string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
                    SqlConnection con = new SqlConnection(constr);
                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter("select * from products where Id=" + Request.QueryString["Id"], con);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    dr["sno"] = sr+1;
                    dr["pid"] = ds.Tables[0].Rows[0]["Id"].ToString();
                    dr["pname"] = ds.Tables[0].Rows[0]["name"].ToString();
                    dr["proimg"] = ds.Tables[0].Rows[0]["image"].ToString();
                    dr["cost"] = ds.Tables[0].Rows[0]["price"].ToString();
                    dr["qun"] = Request.QueryString["quantity"];

                    int price = Convert.ToInt32(ds.Tables[0].Rows[0]["price"].ToString());
                    int quantity = Convert.ToInt16(Request.QueryString["quantity"].ToString());
                    int totalPrice = price * quantity;
                    dr["total"] = totalPrice;
                    dt.Rows.Add(dr);

                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    Session["buyitems"] = dt;
                    paymentbut.Enabled = true;

                    GridView1.FooterRow.Cells[5].Text = "Total Amount";
                    GridView1.FooterRow.Cells[6].Text = grandtotal().ToString();
                    Response.Redirect("ViewCart.aspx");
                }
            }
            else
            {
                dt = Session["buyitems"] as DataTable;
                GridView1.DataSource = dt;
                GridView1.DataBind();
                if (GridView1.Rows.Count > 0)
                {
                    GridView1.FooterRow.Cells[5].Text = "Total Amount";
                    GridView1.FooterRow.Cells[6].Text = grandtotal().ToString();
                }
            }
        }

        //generate order date
        string orderdate = DateTime.Now.ToShortDateString();
        Session["orderdate"] = orderdate;
        orderid();
    }

    //calculating final total
    public int grandtotal()
    {
        DataTable dt = new DataTable();
        dt = Session["buyitems"] as DataTable;
        int nrow = dt.Rows.Count;
        int i = 0;
        int totalamount = 0;
        while (i < nrow)
        {
            totalamount = totalamount + Convert.ToInt32(dt.Rows[i]["total"]);
            i = i + 1;
        }
        return totalamount;
    }

    //generate random order id
    public void orderid()
    {
        string alpha = "abcdefghijklmnopqrstuvwxyz123456789";
        Random r = new Random();
        char[] myArray = new char[5];
        for (int i = 0; i < 5; i++)
        {
            myArray[i] = alpha[(int)(35 * r.NextDouble())];
        }
        string orderid;
        orderid =  DateTime.Now.Hour.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + new string(myArray) + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString();
        Session["orderid"] = orderid;
    }

    //deleting certain row from gridview
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = new DataTable();
        dt = Session["buyitems"] as DataTable;

        for (int i = 0; i <= dt.Rows.Count - 1; i++)
        {
            int sr;
            int sr1;
            string qdata;
            string dtdata;
            sr = Convert.ToInt32(dt.Rows[i]["sno"].ToString());
            TableCell cell = GridView1.Rows[e.RowIndex].Cells[0];
            qdata = cell.Text;
            dtdata = sr.ToString();
            sr1 = Convert.ToInt32(qdata);
            TableCell prID = GridView1.Rows[e.RowIndex].Cells[1];

            if (sr == sr1)
            {
                dt.Rows[i].Delete();
                dt.AcceptChanges();

                string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
                SqlConnection con = new SqlConnection(constr);
                con.Open();
                break;
            }
        }

        //setting sno. after deleting certain product from cart
        for (int i = 1; i <= dt.Rows.Count; i++)
        {
            dt.Rows[i - 1]["sno"] = i;
            dt.AcceptChanges();
        }
        Session["buyitems"] = dt;
        Response.Redirect("ViewCart.aspx");
    }

    //Payment page will displayed
    protected void paymentbut_Click(object sender, EventArgs e)
    {

        if(GridView1.Rows.Count.ToString() == "0")
        {
            Response.Write("<script>alert('Your cart is empty you cannot place an order');</script>");
        }
        else
        {
            Response.Redirect("Payment.aspx");
        }
    }
}


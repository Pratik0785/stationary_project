﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        con.Open();

        //insert data into table
        string insert_query = "insert into register values(@name,@email,@username,@password,@cpassword)";
        SqlCommand cmd1 = new SqlCommand(insert_query, con);
        cmd1.Parameters.AddWithValue("@name", TextBox1.Text);
        cmd1.Parameters.AddWithValue("@email", TextBox2.Text);
        cmd1.Parameters.AddWithValue("@username", TextBox3.Text);
        cmd1.Parameters.AddWithValue("@password", TextBox4.Text);
        cmd1.Parameters.AddWithValue("@cpassword", TextBox5.Text);
        cmd1.ExecuteNonQuery();
        Response.Write("<script>alert('Registration Successful!');</script>");
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
    }
}
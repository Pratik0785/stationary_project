﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        linkbutton1.CausesValidation = false;
        linkbutton3.CausesValidation = false;
        linkbutton4.CausesValidation = false;
        linkbutton5.CausesValidation = false;
        linkbutton6.CausesValidation = false;
    }
    protected void linkbutton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminHome.aspx");
    }
    protected void linkbutton3_Click(object sender, EventArgs e)
    {
           Response.Redirect("NotesOrders.aspx");
    }
    protected void linkbutton4_Click(object sender, EventArgs e)
    {
            Response.Redirect("UpdateProduct.aspx");
    }
    protected void linkbutton5_Click(object sender, EventArgs e)
    {    
        Response.Redirect("ViewReview.aspx");
    }
    protected void linkbutton6_Click(object sender, EventArgs e)
    {
        Session.Remove("admin");
        Response.Redirect("AdminLogin.aspx");
    }
}

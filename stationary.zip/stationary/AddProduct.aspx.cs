﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class AddProduct : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        getid();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile == true)
        {
            FileUpload1.SaveAs(Server.MapPath("Images/") + Label2.Text + ".jpg");
            string image = "Images/" + Label2.Text + ".jpg";
            string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            String query = "insert into products(Id,name,price,image,category) values(" + Label3.Text + ",'" + TextBox1.Text + "','" + TextBox2.Text + "','" + image + "'," + DropDownList1.SelectedItem.ToString()+"')";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            Response.Redirect("<script>alert('New Product Has Been Added Successfully')</script>");
            getid();
        }
        else
        {
            Response.Redirect("<script>alert('Kindly Choose Your Product Image File')</script>");
        }
    }

    private void getid()
    {
        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        String query = "select Id from products";
        SqlCommand cmd = new SqlCommand(query, con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        sda.Fill(ds);
        con.Close();
        if (ds.Tables[0].Rows.Count < 1)
        {
            Label2.Text = "1";

        }
        else
        {
            string constr1 = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            SqlConnection con1 = new SqlConnection(constr1);
            con.Open();
            String query1 = "select max(Id) from products";
            SqlCommand cmd1 = new SqlCommand(query1, con1);
            SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
            DataSet ds1 = new DataSet();
            sda1.Fill(ds1);
            Label2.Text = ds1.Tables[0].Rows[0][0].ToString();
            int a;
            a = Convert.ToInt16(Label2.Text);
            a = a + 1;
            Label2.Text = a.ToString();
            con1.Close();
        }
    }
}
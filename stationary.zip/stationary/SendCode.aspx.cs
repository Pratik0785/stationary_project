﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Web.ApplicationServices;
using System.Web.Security;

public partial class SendCode : System.Web.UI.Page
{
    String randomCode;
    public static String to;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string from, pass, messageBody;
        Random r = new Random();
        randomCode = (r.Next(999999)).ToString();

        //store random generated code into viewstate
        ViewState["msgotp"] = randomCode;
        MailMessage msg = new MailMessage();
        to = (TextBox1.Text).ToString();
        from = "xeroxcenter037@gmail.com";
        pass = "autoxerox";
        messageBody = "Your Reset Code is: " + randomCode;
        msg.To.Add(to);
        msg.From = new MailAddress(from);
        msg.Body = messageBody;
        msg.Subject = "Password Reseting Code";
        SmtpClient smtp = new SmtpClient("smtp.gmail.com");
        smtp.EnableSsl = true;
        smtp.Port = 587;
        smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
        smtp.UseDefaultCredentials = false;
        smtp.Credentials = new NetworkCredential(from, pass);
        try
        {
            smtp.Send(msg);
            codesend.Text = "Code send Successfully";
        }
        catch (Exception ex)
        {
            codesend.Text = ex.Message;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //if otp is correct redirect to ResetPassword page
        if(TextBox2.Text==ViewState["msgotp"].ToString())
        {
            Response.Redirect("ResetPassword.aspx");
        }
        else
        {
            verifycode.Text = "Wrong code";
        }
    }
}
